import { Component } from '@angular/core';
import { Http } from '@angular/http';
import { AppService } from './app.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers :[AppService]
})
export class AppComponent {
  title = 'app';
message :string;
  constructor(private appService: AppService) {

  }

  batchCall() {
    console.log("Welcome");
    this.appService.job().subscribe(data => {
      this.message= data["result"];
      
    });
    console.log("End : " + this.message);
    
  }
}
